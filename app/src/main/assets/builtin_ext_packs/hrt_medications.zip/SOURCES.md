# 数据来源

最后核对日期：`2026-11-14`

| 条目 | 关键数据 | 来源 |
|---|---|---|
| 戊酸雌二醇口服 | Tmax 约 1.5–12 小时，中位数约 3–6 小时 | DailyMed: <https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=estradiol%20valerate> |
| 雌二醇贴片 | 血清雌二醇在数小时内升高，峰值约为 24–42 小时 | DailyMed: <https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=estradiol%20transdermal%20system> |
| Progynon-Depot 油剂肌注 | 每 1 mL 含戊酸雌二醇 10 mg，芝麻油；Tmax 3–5 天，表观 t1/2 约 4–5 天 | PMDA: <https://www.pmda.go.jp/PmdaSearch/rdDetail/iyaku/2473402A2059_1?user=1> |
| Progynon-Depot Interview Form | 油剂组成、Tmax、半衰期和 1–4 周给药间隔 | PMDA IF: <https://www.info.pmda.go.jp/go/interview/1/670109_2473402A2059_1_006_1F.pdf> |
| 醋酸环丙孕酮 | Tmax 3–4 小时，血浆 t1/2 约 38 小时 | Health Canada: <https://pdf.hres.ca/dpd_pm/00063833.PDF> |
| 螺内酯 | 母药 Tmax 2.6 小时，t1/2 1.4 小时；活性代谢物 t1/2 约 14–17 小时 | DailyMed: <https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=spironolactone> |
| 比卡鲁胺 | 活性 R-异构体 Tmax 约 31 小时，t1/2 约 5.8 天 | DailyMed: <https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=bicalutamide> |
| 黄体酮口服 | 微粒化胶囊 Tmax 通常约 1.5–3 小时；食物可增加生物利用度 | DailyMed: <https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=progesterone> |
| 黄体酮直肠 | 小样本研究显示直肠给药 8 小时代谢暴露较高，24 小时仍可高于基线 | PubMed 3612635: <https://pubmed.ncbi.nlm.nih.gov/3612635/> |
| 醋酸甲羟孕酮口服 | Tmax 约 2–4 小时，t1/2 约 11–17 小时 | DailyMed: <https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=medroxyprogesterone%20acetate> |
| 醋酸甲羟孕酮肌注 | 150 mg 肌注峰值约 3 周，t1/2 约 50 天，可检测至 120–200 天 | DailyMed: <https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=medroxyprogesterone%20acetate> |
| 地屈孕酮 | 母药 Tmax 0.5–2.5 小时；DHD Tmax 约 1.5 小时；t1/2 分别约 5–7 和 14–17 小时 | EMC SmPC: <https://www.medicines.org.uk/emc/product/101122/smpc> |
| 雌二醇舌下 | 跨性别女性单次 1 mg 研究：舌下峰值约 1 小时，明显高于口服峰值 | PubMed 34781041: <https://pubmed.ncbi.nlm.nih.gov/34781041/> |
| 戈舍瑞林 3.6 mg 植入 | 皮下植入，每 28 天给药；初始可刺激激素，随后抑制 | DailyMed: <https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=Zoladex> |
| 戈舍瑞林 10.8 mg 植入 | 皮下植入，每 12 周给药；不可与 3.6 mg 植入相加或互换 | DailyMed: <https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=Zoladex> |
| 组氨瑞林 50 mg 植入 | 皮下植入，连续释放约 65 µg/day，12 个月后取出 | DailyMed: <https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=Supprelin%20LA> |

## 使用规则

1. 官方最新版药品说明书优先于本扩展包。
2. 不同国家、生产企业、浓度和释放系统可能具有不同药代参数。
3. 来源链接失效或标签更新时，应重新核对并提升扩展包版本号。
4. 不得把组合制剂标签中的单一成分数据无条件外推到其他制剂。

## 结构化相互作用来源

- 雌激素、黄体酮、MPA、螺内酯和比卡鲁胺：对应 DailyMed 说明书中的 Pharmacokinetics / Drug Interactions 部分
- 醋酸环丙孕酮：加拿大卫生部产品专论
- 地屈孕酮：英国 EMC 的 Nalvee 10 mg SmPC

相互作用的分类用于界面提示，不替代处方审核。`dangerous`、`unsafe` 和 `uncertain` 是扩展包的呈现等级，不等同于监管机构正式严重性分级。

## 不良反应数据口径

- 发生率只有在官方说明书提供对应研究和人群时才写入，并保留联用药物、剂量或时间条件。
- 不同产品、适应证、剂量和人群的发生率不能直接比较。
- 资料不足或仅有上市后自发报告时，安全使用中明确写明“无法统一量化”，不估算百分比。
- 比卡鲁胺的发生率来自与 LHRH 类似物联用的研究，不能当作单药发生率。
- 黄体酮部分发生率来自与结合雌激素联用的研究，不能全部归因于黄体酮单药。

## 复核周期

- 来源访问日期：`2026-11-14`
- 下次复核日期：`2027-05-14`
- 复核周期：六个月
- 当前复核人：扩展包维护者
- 临床审核状态：尚未经过独立临床审核

## 化学标识

分子式和 CAS 号通过 PubChem PUG REST 查询并核对：

- 戊酸雌二醇：CID 13791，C23H32O3，CAS 979-32-8
- 雌二醇：CID 5757，C18H24O2，CAS 50-28-2
- 醋酸环丙孕酮：CID 9880，C24H29ClO4，CAS 427-51-0
- 螺内酯：CID 5833，C24H32O4S，CAS 52-01-7
- 比卡鲁胺：CID 2375，C18H14F4N2O4S，CAS 90357-06-5
- 黄体酮：CID 5994，C21H30O2，CAS 57-83-0
- 醋酸甲羟孕酮：CID 6279，C24H34O4，CAS 71-58-9
- 地屈孕酮：CID 9051，C21H28O2，CAS 152-62-5

PubChem 查询入口：<https://pubchem.ncbi.nlm.nih.gov/>

## HRT 剂量桶依据

主要参考 Rainbow Health Ontario 的女性化激素治疗指南和常见 HRT 临床范围：

- <https://www.rainbowhealthontario.ca/TransHealthGuide/gp-femht.html>

剂量桶只用于 Journal 的曲线高度分组，不代表推荐剂量或起始剂量。注射剂和长效剂型还必须结合实际给药间隔。

比卡鲁胺在女性化治疗中通常属于超说明书用途，其阈值标记为 `hrt-off-label-typical-v1`，不能与前列腺癌说明书剂量混淆。

## 参考浓度模型

参考 Cmax/Tmax 和不可量化原因见 `CONCENTRATIONS.md`。原始来源与对应药代章节如下：

- 口服戊酸雌二醇：DailyMed estradiol valerate 标签
- 雌二醇舌下：PubMed 34781041，跨性别女性 1 mg 单次给药
- EstroGel：DailyMed EstroGel 标签
- 雌二醇贴片：DailyMed estradiol transdermal system 标签
- 醋酸环丙孕酮：加拿大卫生部产品专论
- 比卡鲁胺：DailyMed bicalutamide 标签
- 黄体酮：DailyMed Prometrium 标签
- MPA：DailyMed Provera / Depo-Provera 标签
- 地屈孕酮：EMC Nalvee SmPC
