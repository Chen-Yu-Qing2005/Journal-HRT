#!/usr/bin/env python3
"""Print reference concentration models embedded in the extension pack."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ROOT_SUBSTANCES = ROOT / "substances" / "root"
ZH_SUBSTANCES = ROOT / "substances" / "zh_cn"


def fmt_number(value: float) -> str:
    return f"{value:g}"


def fmt_cmax(model: dict) -> str:
    if model.get("status") == "reference_range":
        value = (
            f"{fmt_number(model['cmaxMin'])}-"
            f"{fmt_number(model['cmaxMax'])} {model['cmaxUnits']}"
        )
        mg_l = (
            f"{fmt_number(model['cmaxMgPerLMin'])}-"
            f"{fmt_number(model['cmaxMgPerLMax'])} mg/L"
        )
        return f"{value}; {mg_l}"
    if "cmax" in model:
        return (
            f"{fmt_number(model['cmax'])} {model['cmaxUnits']}; "
            f"{fmt_number(model['cmaxMgPerL'])} mg/L"
        )
    return "not reported"


def fmt_tmax(model: dict) -> str:
    tmax = model.get("tmax")
    if tmax is not None:
        return f"{fmt_number(tmax)} {model['tmaxUnits']}"
    tmax_median = model.get("tmaxMedian")
    if tmax_median is not None:
        return (
            f"median {fmt_number(tmax_median)}, "
            f"range {fmt_number(model['tmaxMin'])}-"
            f"{fmt_number(model['tmaxMax'])} {model['tmaxUnits']}"
        )
    if model.get("tmaxMin") is not None:
        return (
            f"{fmt_number(model['tmaxMin'])}-"
            f"{fmt_number(model['tmaxMax'])} {model['tmaxUnits']}"
        )
    return "not reported"


def main() -> None:
    print("| 药物 | 途径 | 分析物 | 参考剂量 | Cmax | Tmax | 状态 |")
    print("|---|---|---|---|---|---|---|")
    for path in sorted(ROOT_SUBSTANCES.glob("*.json")):
        substance = json.loads(path.read_text(encoding="utf-8"))
        models = substance.get("concentrationModels", {})
        if not models:
            continue
        zh_path = ZH_SUBSTANCES / path.name
        zh = json.loads(zh_path.read_text(encoding="utf-8"))
        display_name = zh.get("localizedName", substance["name"])
        for route, model in models.items():
            dose = "not applicable"
            if "referenceDose" in model:
                dose = (
                    f"{fmt_number(model['referenceDose'])} "
                    f"{model['referenceDoseUnits']}"
                )
            print(
                f"| {display_name} | {route} | {model.get('analyte', '')} | "
                f"{dose} | {fmt_cmax(model)} | {fmt_tmax(model)} | "
                f"{model.get('status', 'unknown')} |"
            )


if __name__ == "__main__":
    main()
