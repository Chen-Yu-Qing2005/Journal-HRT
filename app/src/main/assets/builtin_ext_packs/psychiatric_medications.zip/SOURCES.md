# Sources

Primary sources were audited on 2026-11-17. U.S. entries link to a specific DailyMed
label identified through the openFDA drug-label endpoint rather than a generic search page.

## FDA / DailyMed

- Aripiprazole: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=02a4af27-c83c-4166-950c-7a1cb12d198d
- Buspirone: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=02628a0c-bfdb-4a58-8e48-bcd8ca12d53b
- Citalopram: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0109f365-bebd-4810-a56f-4451e10245db
- Clozapine: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=09231d80-6343-4a34-bd5b-100c547fd3c9
- Daridorexant: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=3a2d1503-b816-40c9-9fac-7e03c5a3bcef
- Desvenlafaxine: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0f43610c-f290-46ea-d186-4f998ed99fce
- Duloxetine: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=00628e5e-4c5b-2573-e063-6294a90a0e3b
- Escitalopram: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0458445b-e431-4c82-86b8-90373813c10a
- Fluoxetine: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=02283de9-6087-45f7-a9ce-3b082ce860de
- Fluvoxamine: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0a6836ab-bd0e-410b-82af-07720e386532
- Hydroxyzine: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=02616eee-a1a4-4afc-b84e-69fd28755138
- Lamotrigine: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=003663e5-c0c7-4fc1-a64d-313f2a5b10d2
- Lemborexant: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=7074cb65-77b3-45d2-8e8d-da8dc0f70bfd
- Lurasidone: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0115b2fa-4c11-4f91-abe7-8293903e066c
- Paliperidone: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=018cf3ca-bee9-23a6-e063-6394a90ad905
- Paroxetine: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=009d8b89-eab9-43ba-b077-86bfa993a745
- Ramelteon: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=00f0fbda-eb62-4f79-ae9c-286b31eca733
- Sertraline: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=00179766-980b-44b0-99d3-1fee2bb27e37
- Suvorexant: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=1e243ffb-31be-39a7-4946-83ce7b839e0a
- Tasimelteon: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=46b09064-a675-92d5-24a7-dac0410f77ae
- Trazodone: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=007f38e0-653b-43e4-a1c1-b59997b2762a
- Venlafaxine: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=017a84aa-0e1f-f560-e063-6294a90a9069
- Vortioxetine: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=1a5b68e2-14d0-419d-9ec6-1ca97145e838
- Ziprasidone: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0071a228-21cc-56a6-dcc9-a7a6ceea758c

## EMA and UK SmPC

- Agomelatine: https://www.ema.europa.eu/en/documents/product-information/valdoxan-epar-product-information_en.pdf
- Amisulpride: https://www.medicines.org.uk/emc/product/102319/smpc

## Audit

- Detailed results: `PSYCHIATRIC_LITERATURE_AUDIT.md`

Labels differ by manufacturer, formulation, indication, age, hepatic function, CYP phenotype,
and interacting medicines. The extension does not merge those populations into one clinical rule.
