# Clinical boundary

This extension is for personal record keeping and medication-exposure visualization.
It is not medical advice, a prescription, a dose recommendation, or a substitute for the
current approved label and professional care.

Do not start, stop, switch, combine, or adjust psychiatric medicines from this extension.
Seek urgent care for suicidal thoughts, severe agitation, serotonin syndrome, severe rash,
high fever, muscle rigidity, abnormal heart rhythm, seizure, or other acute deterioration.
