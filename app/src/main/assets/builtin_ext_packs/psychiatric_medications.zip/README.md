# Psychiatric Medications Extension

Source batch 0.3.0 contains 26 commonly encountered psychiatric medicines:

- SSRIs: escitalopram, sertraline, citalopram, paroxetine, fluvoxamine, fluoxetine
- SNRIs: venlafaxine, desvenlafaxine, duloxetine
- Other antidepressants: trazodone, vortioxetine, agomelatine
- Antipsychotics: clozapine, aripiprazole, paliperidone, lurasidone, amisulpride, ziprasidone
- Mood stabilizer: lamotrigine
- Anxiolytics: buspirone, hydroxyzine
- Orexin antagonists: suvorexant, lemborexant, daridorexant
- Melatonin receptor agonists: ramelteon, tasimelteon

The base Journal catalog already supplies common records for bupropion, mirtazapine,
tianeptine, quetiapine, olanzapine, risperidone, haloperidol, lithium, gabapentin,
pregabalin, selected benzodiazepines, and prescribed hypnotics.

This source batch is validated but has not yet been packaged into the APK. The timeline is a
medication-exposure aid, not a prediction of clinical response or a substitute for monitoring.
