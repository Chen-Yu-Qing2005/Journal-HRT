# Changelog

## 0.3.1 source audit - 2026-11-17

- Replaced generic DailyMed search pages with 24 specific SPL `setid` sources.
- Added direct EMA product information for agomelatine and UK SmPC for amisulpride.
- Added `PSYCHIATRIC_LITERATURE_AUDIT.md` with per-medication review results.
- Checked existing Tmax and half-life values against their cited labels.
- Kept unsupported pharmacokinetic values as `not_reported` rather than filling estimates.

## 0.3.0 source - 2026-11-15

- Added orexin receptor antagonists: suvorexant, lemborexant, and daridorexant.
- Added melatonin receptor agonists: ramelteon and tasimelteon.
- Verified terminal or effective half-life against current labels.
- Added regulatory badges for Chinese psychotropic class I/II, narcotics, and U.S. Schedule IV.

## 0.2.0 source - 2026-11-15

- Added common SNRIs, serotonergic antidepressants, atypical antipsychotics, lamotrigine, buspirone, and hydroxyzine.
- Excluded dementia medications from the psychiatric browse group.
- Changed psychiatric browse grouping to a curated common-medication allowlist instead of broad category matching.
- Source files validated; packaging intentionally deferred.

## 0.1.0 - 2026-11-15

- Initial six-SSRI batch.
