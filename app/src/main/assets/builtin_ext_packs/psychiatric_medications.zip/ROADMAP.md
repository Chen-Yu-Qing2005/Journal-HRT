# Roadmap

## Completed source work

- Six common SSRIs
- Three common SNRIs
- Three other common antidepressants
- Six additional atypical antipsychotics
- Lamotrigine
- Buspirone and hydroxyzine

## Later candidates

- Additional common ADHD, addiction-psychiatry, sleep, and rare treatment-resistance medicines
- Product-specific monitoring pages where needed
- Region-specific labeling where Chinese and U.S. indications differ

## Deferred until psychiatric source work is complete

Add evidence-based extended-release presets only for individual medicines with product-specific
release information, such as quetiapine. Do not apply a global default extended-release profile.
